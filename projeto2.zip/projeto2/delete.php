<?php
include 'config.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    die("ID inválido.");
}

try {
    // Iniciar uma transação para garantir que tudo seja deletado corretamente
    $pdo->beginTransaction();

    // Deletar os comentários associados ao tópico
    $sql = "DELETE FROM redmasca_comentarios WHERE topic_id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $id]);

    // Deletar as associações de tags na tabela topic_tags
    $sql = "DELETE FROM redmasca_topicos_tags WHERE topic_id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $id]);

    // Opcional: Deletar tags que ficaram órfãs (sem nenhum vínculo em topic_tags)
    $sql = "DELETE t FROM redmasca_tags t LEFT JOIN redmasca_topicos_tags tt ON t.id = tt.tag_id WHERE tt.tag_id IS NULL";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();

    // Deletar o tópico da tabela topics
    $sql = "DELETE FROM redmasca_topicos WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $id]);

    // Confirmar as alterações no banco
    $pdo->commit();

    // Redirecionar para a página principal
    header("Location: read.php");
    exit;

} catch (PDOException $e) {
    // Em caso de erro, reverter todas as alterações
    $pdo->rollBack();
    die("Erro ao excluir o tópico: " . $e->getMessage());
}
?>