<?php 
require 'config.php';  
$erro = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {     
    $username = $_POST['username'];     
    $email = $_POST['email'];     
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);     
    $curso_id = $_POST['curso_id'];  

    // Verificar se o nome de usuário já existe     
    $sql = "SELECT * FROM redmasca_usuario WHERE username = :username";     
    $stmt = $pdo->prepare($sql);     
    $stmt->execute(['username' => $username]);     
    $existingUser  = $stmt->fetch(PDO::FETCH_ASSOC);  

    // Verificar se o e-mail já existe     
    $sql = "SELECT * FROM redmasca_usuario WHERE email = :email";     
    $stmt = $pdo->prepare($sql);     
    $stmt->execute(['email' => $email]);     
    $existingEmail = $stmt->fetch(PDO::FETCH_ASSOC);  

    // Se o usuário ou email já existir, definir a mensagem de erro     
    if ($existingUser  || $existingEmail) {         
        $erro = "O nome de usuário ou e-mail já estão cadastrados.";     
    } else {         
        // Inserir o usuário no banco de dados         
        $sql = "INSERT INTO redmasca_usuario (username, email, password, curso_id) VALUES (:username, :email, :password, :curso_id)";         
        $stmt = $pdo->prepare($sql);         
        $stmt->execute([             
            'username' => $username,             
            'email' => $email,             
            'password' => $password,             
            'curso_id' => $curso_id         
        ]);  

        header("Location: login.php");         
        exit();     
    } 
}  

// Buscar cursos da tabela categories 
$stmt = $pdo->query("SELECT * FROM redmasca_categorias"); 
$courses = $stmt->fetchAll(); 
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Registrar</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: url('telaregister.jpeg') no-repeat center center/cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: white;
            position: relative;
        }

        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            z-index: 1;
        }

        .container {
            position: relative;
            z-index: 2;
            background: rgba(255, 255, 255, 0.1);
            padding: 30px;
            border-radius: 10px;
            backdrop-filter: blur(10px);
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        h1 {
            margin-bottom: 20px;
            font-size: 24px;
        }

        label {
            display: block;
            text-align: left;
            margin: 10px 0 5px;
            font-size: 14px;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: none;
            font-size: 16px;
        }

        button {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn-primary {
            background: #ff9404;
            color: white;
        }

        .btn-primary:hover {
            background: darkgreen;
        }

        .btn-secondary {
            background: transparent;
            color: white;
            border: 1px solid white;
            margin-top: 10px;
        }

        .btn-secondary:hover {
            background: white;
            color: black;
        }

        .error-message {
            background-color: rgba(255, 0, 0, 0.1);
            color: #ff4d4d;
            border: 1px solid #ff4d4d;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="overlay"></div>

<div class="container">
    <h1>Registrar-se</h1>

    <?php if (!empty($erro)): ?>
        <div class="error-message"><?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>

    <form method="POST" action="register.php">
        <label for="username">Usuário:</label>
        <input type="text" name="username" required>

        <label for="email">Email:</label>
        <input type="email" name="email" required>

        <label for="password">Senha:</label>
        <input type="password" name="password" required>

        <label for="curso_id">Curso:</label>
        <select name="curso_id" required>
            <option value="">Selecione um curso</option>
            <?php foreach ($courses as $course): ?>
                <option value="<?= htmlspecialchars($course['id']) ?>"><?= htmlspecialchars($course['name']) ?></option>
            <?php endforeach; ?>
        </select>

        <button type="submit" class="btn-primary">Registrar</button>
        <button type="button" class="btn-secondary" onclick="window.location.href='login.php'">Voltar</button>
    </form>
</div>

</body>
</html>
