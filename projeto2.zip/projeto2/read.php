<?php
// conexão com o banco de dados
include 'config.php';
// iniciar uma nova sessão ou retomar uma sessão existente
session_start();
// Verifica se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header("Location:login.php");
    exit();
}

include 'config.php';

// Processar o envio do formulário para criar um novo post
/*
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_post'])) {
Esta linha verifica se o método de requisição HTTP é POST e se o campo create_post está definido no array $_POST.

 Inicia um bloco try, que é usado para capturar exceções que podem ocorrer durante a execução do código dentro dele.

                   $title = $_POST['title'];
                    $content = $_POST['content'];
                    $category_id = $_POST['category_id'];
                    $selected_tags = $_POST['selected_tags'] ?? '';
Aqui, os valores dos campos do formulário são atribuídos a variáveis
$selected_tags: tags selecionadas, que usa o operador de coalescência nula (??) para garantir que, se não estiver definido, será uma string vazia.
*/
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_post'])) {
    try {
        $title = $_POST['title'];
        $content = $_POST['content'];
        $category_id = $_POST['category_id'];
        $selected_tags = $_POST['selected_tags'] ?? '';

        // Upload de imagem
        /*
                    $image_path = null;
Inicializa a variável $image_path como null. Esta variável será usada para armazenar o caminho da imagem carregada

                      if (!empty($_FILES['image']['name'])) {
Verifica se um arquivo de imagem foi enviado. A condição !empty() garante que o nome do arquivo não esteja vazio.

                                $target_dir = "uploads/";
                            $target_file = $target_dir . basename($_FILES['image']['name']);
Define o diretório de destino para o upload da imagem como uploads/ e cria o caminho completo do arquivo de destino concatenando o diretório com o nome do arquivo enviado.

            if (!is_dir($target_dir)) {
                mkdir($target_dir, 0755, true); // Cria a pasta de uploads, se não existir
Verifica se o diretório de uploads não existe. Se não existir, ele cria o diretório com permissões 0755. O parâmetro true permite a criação de diretórios pai, se necessário.

            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                $image_path = $target_file;
            } else {
                throw new Exception("Falha ao fazer upload da imagem.");
Tenta mover o arquivo temporário enviado para o diretório de destino. Se a operação for bem-sucedida, o caminho do arquivo é armazenado em $image_path. Caso contrário, uma exceção é lançada com uma mensagem de erro.



        */
        $image_path = null;
        if (!empty($_FILES['image']['name'])) {
            $target_dir = "uploads/";
            $target_file = $target_dir . basename($_FILES['image']['name']);

            if (!is_dir($target_dir)) {
                mkdir($target_dir, 0755, true); // Cria a pasta de uploads, se não existir
            }

            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                $image_path = $target_file;
            } else {
                throw new Exception("Falha ao fazer upload da imagem.");
            }
        }

        // Inserir o post no banco de dados
        $sql = "INSERT INTO redmasca_topicos (title, content, category_id, image_path, user_id, created_at) 
        VALUES (:title, :content, :category_id, :image_path, :user_id, NOW())";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'title' => $title,
            'content' => $content,
            'category_id' => $category_id,
            'image_path' => $image_path,
            'user_id' => $_SESSION['user_id'] // Adiciona o ID do usuário logado
        ]);


        // Obter o ID do post recém-criado
        $topic_id = $pdo->lastInsertId();

        // Inserir tags na tabela topic_tags (se houver tags selecionadas)
        /*
                    if (!empty($selected_tags)) {
Esta linha verifica se a variável $selected_tags não está vazia. Isso significa que o usuário selecionou algumas tags para o post.

                        $tag_ids = explode(',', $selected_tags);
A função explode() é usada para dividir a string $selected_tags em um array, usando a vírgula como delimitador. O resultado é armazenado na variável $tag_ids, que conterá os IDs das tags selecionadas.

                        foreach ($tag_ids as $tag_id) {
Inicia um loop foreach que itera sobre cada ID de tag no array $tag_ids.


                            if (!empty(trim($tag_id))) {
Para cada $tag_id, verifica se não está vazio após remover espaços em branco no início e no final da string usando trim(). Isso garante que apenas IDs válidos sejam processados.

                             $sql_tag = "INSERT INTO redmasca_topicos_tags (topic_id, tag_id) VALUES (:topic_id, :tag_id)";
Define uma consulta SQL para inserir um novo registro na tabela redmasca_topicos_tags, que associa um tópico (post) a uma tag. Os valores para topic_id e tag_id serão passados como parâmetros.


        */
        if (!empty($selected_tags)) {
            $tag_ids = explode(',', $selected_tags);
            foreach ($tag_ids as $tag_id) {
                if (!empty(trim($tag_id))) {
                    $sql_tag = "INSERT INTO redmasca_topicos_tags (topic_id, tag_id) VALUES (:topic_id, :tag_id)";
                    $stmt_tag = $pdo->prepare($sql_tag);
                    $stmt_tag->execute([
                        'topic_id' => $topic_id,
                        'tag_id' => trim($tag_id)
                    ]);
                }
            }
        }

        // Redirecionar para evitar reenvio do formulário
        header("Location: read.php?success=1");

        exit();
    } catch (Exception $e) {
        echo "Erro: " . $e->getMessage();
    }
}

// Processar o envio do formulário para criar uma nova tag
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_tag'])) {
    $tag_name = $_POST['tag_name'];
    $sql = "INSERT INTO redmasca_tags (name) VALUES (:name)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['name' => $tag_name]);

    header("Location: read.php");
    exit;
}

// Buscar categorias e tags
$stmt = $pdo->query("SELECT * FROM redmasca_categorias");
//O método fetchAll() é chamado no objeto $stmt para recuperar todos os resultados da consulta em um array.
$categories = $stmt->fetchAll();

$stmt = $pdo->query("SELECT * FROM redmasca_tags");
$tags = $stmt->fetchAll();

// Capturar filtros de pesquisa
/*
            $search = $_GET['search'] ?? '';
 Esta linha está utilizando o operador de coalescência nula (??). Ele verifica se a variável $_GET['search'] está definida e não é nula. Se estiver, o valor de $_GET['search'] é atribuído à variável $search. Caso contrário, $search recebe uma string vazia (''). Isso é útil para evitar erros caso a chave search não esteja presente na URL.

            $category_id = $_GET['category_id'] ?? null;
Similar à linha anterior, esta linha verifica se $_GET['category_id'] está definida. Se estiver, o valor é atribuído à variável $category_id. Se não estiver, $category_id recebe o valor null. Isso é útil para indicar que não há uma categoria selecionada.


*/
$search = $_GET['search'] ?? '';
$category_id = $_GET['category_id'] ?? null;
$tag_id = $_GET['tag_id'] ?? null;

// Construir a query base para posts aprovados
/*
Esta parte do código define uma consulta SQL que seleciona todos os campos da tabela redmasca_topicos e o nome da categoria da tabela redmasca_categorias.
A consulta utiliza um JOIN para combinar as tabelas redmasca_topicos e redmasca_categorias com base na correspondência entre category_id de redmasca_topicos e id de redmasca_categorias.
Também utiliza LEFT JOIN para incluir informações de redmasca_topicos_tags e redmasca_tags, permitindo que tópicos sem tags ainda sejam retornados.
A cláusula WHERE filtra os resultados para incluir apenas tópicos que foram aprovados (approved = 1).*/
$sql = "SELECT redmasca_topicos.*, redmasca_categorias.name AS category_name 
        FROM redmasca_topicos 
        JOIN redmasca_categorias ON redmasca_topicos.category_id = redmasca_categorias.id 
        LEFT JOIN redmasca_topicos_tags ON redmasca_topicos.id = redmasca_topicos_tags.topic_id 
        LEFT JOIN redmasca_tags ON redmasca_tags.id = redmasca_topicos_tags.tag_id 
        WHERE redmasca_topicos.approved = 1"; // Exibe apenas posts aprovados

/*
Se a variável $search não estiver vazia, a consulta SQL é modificada para incluir uma condição adicional que verifica se o título ou o conteúdo do tópico contém o termo de busca. O operador LIKE é usado para permitir correspondências parciais.
O valor de $search é adicionado ao array $params, com os caracteres % adicionados para permitir que a busca encontre qualquer ocorrência do termo.*/
$params = [];
if ($search) {
    $sql .= " AND (redmasca_topicos.title LIKE :search OR redmasca_topicos.content LIKE :search)";
    $params['search'] = "%$search%";
}
/*
Se a variável $category_id estiver definida, a consulta é atualizada para incluir uma condição que filtra os tópicos pela categoria específica. O valor de $category_id é adicionado ao array $params.*/
if ($category_id) {
    $sql .= " AND redmasca_topicos.category_id = :category_id";
    $params['category_id'] = $category_id;
}
if ($tag_id) {
    $sql .= " AND redmasca_tags.id = :tag_id";
    $params['tag_id'] = $tag_id;
}
//Após adicionar as condições de filtro, a consulta é finalizada com um GROUP BY para agrupar os resultados por id do tópico e um ORDER BY para ordenar os tópic
$sql .= " GROUP BY redmasca_topicos.id ORDER BY redmasca_topicos.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$topics = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <title>Fórum de Cursos Técnicos</title>
    <style>
        :root {
            --bg-color: #f0f2f5;
            --text-color: #1a1a1a;
            --navbar-bg: #fff;
            --post-bg: #fff;
            --post-shadow: rgba(0, 0, 0, 0.05);
            --border-color: #ddd;
            --tag-bg: #f5f5f5;
            --tag-color: #555;
            --dropdown-bg: #fff;
            --dropdown-shadow: rgba(0, 0, 0, 0.2);
            --success-bg: #d4edda;
            --success-color: #155724;
            --success-border: #c3e6cb;
        }

        [data-theme="dark"] {
            --bg-color: #1a1a1a;
            --text-color: #ffffff;
            --navbar-bg: #2d2d2d;
            --post-bg: #3a3a3a;
            --post-shadow: rgba(0, 0, 0, 0.3);
            --border-color: #555;
            --tag-bg: #555;
            --tag-color: #cccccc;
            --dropdown-bg: #3a3a3a;
            --dropdown-shadow: rgba(0, 0, 0, 0.5);
            --success-bg: #2d5a2d;
            --success-color: #90ee90;
            --success-border: #4a7c4a;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: var(--bg-color);
            color: var(--text-color);
            margin: 0;
            padding: 0;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        h1,
        h2 {
            color: var(--text-color);
            font-weight: 600;
        }

        .container {
            width: 85%;
            margin: 0 auto;
            padding: 20px 0;
        }

        .navbar {
            background: var(--navbar-bg);
            padding: 15px 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
            transition: background-color 0.3s ease;
        }

        .navbar .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar a,
        .menu-btn {
            text-decoration: none;
            color: #ff9404;
            font-weight: 500;
            padding: 10px 20px;
            border-radius: 25px;
            transition: all 0.3s ease;
        }

        .navbar a:hover,
        .menu-btn:hover {
            background: #ff9404;
            color: #fff;
        }

        .menu-btn {
            background: none;
            border: none;
            cursor: pointer;
            font-size: 1em;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background: var(--dropdown-bg);
            min-width: 300px;
            box-shadow: 0 8px 16px var(--dropdown-shadow);
            z-index: 1;
            border-radius: 8px;
            padding: 15px;
            right: 0;
            transition: background-color 0.3s ease;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dropdown-content form {
            display: flex;
            flex-direction: column;
        }

        .dropdown-content input,
        .dropdown-content textarea,
        .dropdown-content select {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid var(--border-color);
            border-radius: 5px;
            box-sizing: border-box;
            background: var(--dropdown-bg);
            color: var(--text-color);
            transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease;
        }

        .dropdown-content button {
            background: #ff9404;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            transition: background 0.3s;
        }

        .dropdown-content button:hover {
            background: #e68503;
        }

        .post {
            background: var(--post-bg);
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px var(--post-shadow);
            transition: transform 0.2s, background-color 0.3s ease;
        }

        .post:hover {
            transform: translateY(-5px);
        }

        .post img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            margin-bottom: 15px;
        }

        .post h2 a {
            color: #ff9404;
            text-decoration: none;
            transition: color 0.3s;
        }

        .post h2 a:hover {
            color: #e68503;
        }

        .tags {
            margin-top: 15px;
        }

        .tag {
            display: inline-block;
            background-color: var(--tag-bg);
            padding: 6px 12px;
            margin: 4px;
            border-radius: 20px;
            font-size: 0.85em;
            color: var(--tag-color);
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #ff9404;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 25px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s ease;
            z-index: 1001;
        }

        .theme-toggle:hover {
            background: #e68503;
        }

        .theme-toggle .icon {
            margin-right: 5px;
        }

        .success-message {
            background: var(--success-bg);
            color: var(--success-color);
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid var(--success-border);
            transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease;
        }

        .tag-selector {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin: 10px 0;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 5px;
            background: var(--dropdown-bg);
            min-height: 50px;
        }

        .selectable-tag {
            display: inline-block;
            background-color: var(--tag-bg);
            color: var(--tag-color);
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.85em;
            cursor: pointer;
            transition: all 0.3s ease;
            user-select: none;
            border: 2px solid transparent;
        }

        .selectable-tag:hover {
            background-color: #ff9404;
            color: white;
            transform: scale(1.05);
        }

        .selectable-tag.selected {
            background-color: #ff9404;
            color: white;
            text-decoration: line-through;
            text-decoration-thickness: 2px;
            text-decoration-color: rgba(255, 255, 255, 0.8);
        }

        .selectable-tag.selected:hover {
            background-color: #e68503;
            text-decoration: none;
        }
    </style>
</head>

<body>

    <button class="theme-toggle" onclick="toggleTheme()">
        <span class="icon">🌙</span>
        <span class="text">Modo Escuro</span>
    </button>

    <div class="navbar">
        <div class="container">
            <h1>Fórum RedMasca</h1>
            <div>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <span>Bem-vindo, <?= htmlspecialchars($_SESSION['username']); ?>!</span>
                    <a href="logout.php">Sair</a>
                    <a href="editarDados.php">Editar Dados</a>
                    <?php if ($_SESSION['user_role'] === 'admin'): ?>
                        <a href="admin.php">Área Admin</a>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="login.php">Login</a>
                    <a href="register.php">Register</a>
                <?php endif; ?>

                <!-- Menu Criar Post -->
                <div class="dropdown">
                    <button class="menu-btn">Criar Post</button>
                    <div class="dropdown-content">
                        <h2>Qual sua dúvida?</h2>
                        <form method="post" action="read.php" enctype="multipart/form-data" id="createPostForm">
                            <input type="hidden" name="create_post" value="1">
                            <input type="text" name="title" placeholder="Título do Post" required>
                            <textarea name="content" placeholder="Conteúdo do Post" rows="4" required></textarea>
                            <select name="category_id" required>
                                <option value="">Escolha a Categoria</option>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?= $category['id'] ?>"><?= htmlspecialchars($category['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <label>Tags (clique para selecionar):</label>
                            <div class="tag-selector">
                                <?php foreach ($tags as $tag): ?>
                                    <span class="selectable-tag" data-tag-id="<?= $tag['id'] ?>" data-tag-name="<?= htmlspecialchars($tag['name']) ?>">
                                        <?= htmlspecialchars($tag['name']) ?>
                                    </span>
                                <?php endforeach; ?>
                            </div>
                            <input type="hidden" name="selected_tags" id="selectedTagsInput" value="">
                            <label>Imagem do Post:</label>
                            <input type="file" name="image" accept="image/*">
                            <button type="submit">Publicar Post</button>
                        </form>
                    </div>
                </div>

                <!-- Menu Criar Tag -->
                <div class="dropdown">
                    <button class="menu-btn">Criar Tag</button>
                    <div class="dropdown-content">
                        <h2>Criar Nova Tag</h2>
                        <form method="post" action="read.php">
                            <input type="hidden" name="create_tag" value="1">
                            <input type="text" name="tag_name" placeholder="Nome da Tag" required>
                            <button type="submit">Criar Tag</button>
                        </form>
                    </div>
                </div>

                <!-- Menu Filtro -->
                <div class="dropdown">
                    <button class="menu-btn">Filtrar</button>
                    <div class="dropdown-content">
                        <form method="get" action="read.php">
                            <select name="category_id">
                                <option value="">Todas as Categorias</option>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?= $category['id'] ?>" <?= $category_id == $category['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($category['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <select name="tag_id">
                                <option value="">Todas as Tags</option>
                                <?php foreach ($tags as $tag): ?>
                                    <option value="<?= $tag['id'] ?>" <?= $tag_id == $tag['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($tag['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit">Filtrar</button>
                        </form>
                    </div>
                </div>

                <!-- Menu Pesquisa -->
                <div class="dropdown">
                    <button class="menu-btn">Pesquisar</button>
                    <div class="dropdown-content">
                        <form method="get" action="read.php">
                            <input type="text" name="search" placeholder="Pesquisar por título ou conteúdo..." value="<?= htmlspecialchars($search) ?>">
                            <button type="submit">Pesquisar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
            <div class="success-message">
                Post criado com sucesso! Aguarde a aprovação.
            </div>
        <?php endif; ?>

        <!-- Listagem de Posts -->
        <?php foreach ($topics as $topic): ?>
            <div class="post">
                <?php if ($topic['image_path']): ?>
                    <img src="<?= htmlspecialchars($topic['image_path']) ?>" alt="Imagem do post">
                <?php endif; ?>
                <h2><a href="view.php?id=<?= $topic['id'] ?>"><?= htmlspecialchars($topic['title']) ?></a></h2>
                <p><?= htmlspecialchars($topic['content']) ?></p>
                <p>Categoria: <?= htmlspecialchars($topic['category_name']) ?></p>
                <div class="tags">
                    <?php
                    $stmt_tags = $pdo->prepare("SELECT redmasca_tags.name FROM redmasca_tags 
                                            JOIN redmasca_topicos_tags ON redmasca_tags.id = redmasca_topicos_tags.tag_id 
                                            WHERE redmasca_topicos_tags.topic_id = :topic_id");
                    $stmt_tags->execute(['topic_id' => $topic['id']]);
                    $post_tags = $stmt_tags->fetchAll();
                    foreach ($post_tags as $tag): ?>
                        <span class="tag"><?= htmlspecialchars($tag['name']) ?></span>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <script>
        // Função para alternar entre os temas
        function toggleTheme() {
            const body = document.body;
            const themeToggle = document.querySelector('.theme-toggle');
            const icon = themeToggle.querySelector('.icon');
            const text = themeToggle.querySelector('.text');

            if (body.getAttribute('data-theme') === 'dark') {
                body.removeAttribute('data-theme');
                icon.textContent = '🌙';
                text.textContent = 'Modo Escuro';
                localStorage.setItem('theme', 'light');
            } else {
                body.setAttribute('data-theme', 'dark');
                icon.textContent = '☀️';
                text.textContent = 'Modo Claro';
                localStorage.setItem('theme', 'dark');
            }
        }

        // Carregar tema salvo ao carregar a página
        document.addEventListener('DOMContentLoaded', function() {
            const savedTheme = localStorage.getItem('theme');
            const body = document.body;
            const themeToggle = document.querySelector('.theme-toggle');
            const icon = themeToggle.querySelector('.icon');
            const text = themeToggle.querySelector('.text');

            if (savedTheme === 'dark') {
                body.setAttribute('data-theme', 'dark');
                icon.textContent = '☀️';
                text.textContent = 'Modo Claro';
            }

            // Gerenciar seleção de tags
            const selectableTags = document.querySelectorAll('.selectable-tag');
            const selectedTagsInput = document.getElementById('selectedTagsInput');
            const selectedTags = new Set();

            selectableTags.forEach(tag => {
                tag.addEventListener('click', function() {
                    const tagId = this.getAttribute('data-tag-id');

                    if (this.classList.contains('selected')) {
                        // Desmarcar tag
                        this.classList.remove('selected');
                        selectedTags.delete(tagId);
                    } else {
                        // Marcar tag
                        this.classList.add('selected');
                        selectedTags.add(tagId);
                    }

                    // Atualizar input hidden com as tags selecionadas
                    selectedTagsInput.value = Array.from(selectedTags).join(',');
                });
            });

            // Processar formulário antes do envio
            const createPostForm = document.getElementById('createPostForm');
            if (createPostForm) {
                createPostForm.addEventListener('submit', function(e) {
                    // Converter tags selecionadas para o formato esperado pelo PHP
                    const selectedTagsArray = Array.from(selectedTags);
                    selectedTagsInput.value = selectedTagsArray.join(',');
                });
            }
        });
    </script>

</body>

</html>