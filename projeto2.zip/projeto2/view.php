<?php
// iniciar uma nova sessão ou retomar uma sessão existente
session_start();
// conexão com o banco de dados
include 'config.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'] ?? null;

if (!$id) {
    die("ID do tópico não especificado.");
}

// Buscar o tópico e o user_id do criador
$sql = "SELECT redmasca_topicos.*, redmasca_categorias.name AS category_name, redmasca_topicos.user_id 
        FROM redmasca_topicos 
        JOIN redmasca_categorias ON redmasca_topicos.category_id = redmasca_categorias.id 
        WHERE redmasca_topicos.id = :id";
$stmt = $pdo->prepare($sql);
$stmt->execute(['id' => $id]);
$topic = $stmt->fetch();

if (!$topic) {
    die("Tópico não encontrado.");
}

// Verificar se o usuário logado é o criador do tópico
$isCreator = ($_SESSION['user_id'] == $topic['user_id']);

// Processar envio de novo comentário
/*               $comment = trim($_POST['comment']);
Aqui, o código obtém o valor do comentário enviado pelo formulário, usando $_POST['comment'], e aplica a função trim() para remover espaços em branco do início e do fim da string. O resultado é armazenado na variável $comment.

                $parent_id = !empty($_POST['parent_id']) ? $_POST['parent_id'] : null;
Esta linha verifica se a variável parent_id foi enviada e não está vazia. Se for o caso, o valor é atribuído à variável $parent_id; caso contrário, $parent_id é definido como null. Isso é útil para identificar se o comentário é uma resposta a outro comentário.

                $user_id = $_SESSION['user_id'];
Aqui, o código obtém o ID do usuário da sessão atual, armazenando-o na variável $user_id. Isso pressupõe que a sessão já foi iniciada e que o ID do usuário está armazenado na variável de sessão*/
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['comment'])) {
    $comment = trim($_POST['comment']);
    $parent_id = !empty($_POST['parent_id']) ? $_POST['parent_id'] : null;
    $user_id = $_SESSION['user_id'];

    if (empty($comment)) {
        die("O comentário não pode estar vazio.");
    }

    // Inserir o comentário no banco de dados
    $sql = "INSERT INTO redmasca_comentarios (topic_id, comment, user_id, parent_id, created_at) 
            VALUES (:topic_id, :comment, :user_id, :parent_id, NOW())";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'topic_id' => $id,
        'comment' => $comment,
        'user_id' => $user_id,
        'parent_id' => $parent_id
    ]);

    header("Location: view.php?id=" . $id);
    exit();
}

// Função para buscar comentários
/*           function fetchComments($pdo, $topic_id, $parent_id = null) {
Esta linha define uma função chamada fetchComments, que aceita três parâmetros:
$pdo: uma instância de PDO (PHP Data Objects) para interagir com o banco de dados.
$topic_id: o ID do tópico cujos comentários devem ser recuperados.
$parent_id: um ID opcional que indica se os comentários são respostas a um comentário específico. O valor padrão é null.

array_filter() é usada para remover valores nulos do array, garantindo que apenas os parâmetros válidos sejam passados.

            return $stmt->fetchAll();
Finalmente, a função retorna todos os resultados da consulta como um array, utilizando o método fetchAll(). Isso retorna todos os comentários que correspondem aos critérios especificados.

*/
function fetchComments($pdo, $topic_id, $parent_id = null) {
    $sql = "SELECT redmasca_comentarios.*, redmasca_usuario.username 
            FROM redmasca_comentarios 
            JOIN redmasca_usuario ON redmasca_comentarios.user_id = redmasca_usuario.id 
            WHERE topic_id = :topic_id AND parent_id " . ($parent_id ? "= :parent_id" : "IS NULL") . " 
            ORDER BY created_at DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array_filter(['topic_id' => $topic_id, 'parent_id' => $parent_id]));
    return $stmt->fetchAll();
}

// Função para exibir comentários recursivamente
/*          function displayComments($pdo, $topic_id, $parent_id = null) {
a linha define uma função chamada displayComments, que aceita três parâmetros:
$pdo: uma instância de PDO (PHP Data Objects) para interagir com o banco de dados.
$topic_id: o ID do tópico cujos comentários devem ser exibidos.
$parent_id: um ID opcional que indica se os comentários são respostas a um comentário específico. O valor padrão é null.

                $comments = fetchComments($pdo, $topic_id, $parent_id);
Aqui, a função chama fetchComments, passando os parâmetros $pdo, $topic_id e $parent_id. O resultado, que é um array de comentários, é armazenado na variável $comments.

                    foreach ($comments as $comment): ?>
Esta linha inicia um loop foreach, que itera sobre cada comentário no array $comments. Para cada iteração, a variável $comment representa um comentário individual.

                                <div class="comment-header">
                            <span class="comment-author"><?= htmlspecialchars($comment['username']) ?></span>
                            <span class="comment-date"><?= date('d/m/Y H:i', strtotime($comment['created_at'])) ?></span>
                        </div>
Dentro do contêiner do comentário, um segundo <div> é aberto para o cabeçalho do comentário.
O nome do autor do comentário é exibido dentro de um <span>, utilizando htmlspecialchars() para escapar caracteres especiais e evitar XSS (Cross-Site Scripting).
A data de criação do comentário é formatada usando a função date() e exibida em um segundo <span>. A data é convertida de uma string para um timestamp usando strtotime().

                                    <div class="comment-content">
                      <?= nl2br(htmlspecialchars($comment['comment'])) ?>
                     </div>
Um novo <div> é aberto para o conteúdo do comentário.
O texto do comentário é exibido, utilizando htmlspecialchars() para escapar caracteres especiais e nl2br() para converter quebras de linha em tags <br>, permitindo que o texto mantenha a formatação original.

*/
function displayComments($pdo, $topic_id, $parent_id = null) {
    $comments = fetchComments($pdo, $topic_id, $parent_id);

    foreach ($comments as $comment): ?>
        <div class="comment">
            <div class="comment-header">
                <span class="comment-author"><?= htmlspecialchars($comment['username']) ?></span>
                <span class="comment-date"><?= date('d/m/Y H:i', strtotime($comment['created_at'])) ?></span>
            </div>
            <div class="comment-content">
                <?= nl2br(htmlspecialchars($comment['comment'])) ?>
            </div>

            <!-- Formulário de resposta -->
            <form method="post" action="" class="comment-form-inline">
                <textarea name="comment" placeholder="Responda a este comentário..." rows="2" required></textarea>
                <input type="hidden" name="parent_id" value="<?= $comment['id'] ?>">
                <button type="submit" class="btn">Responder</button>
            </form>

            <!-- Exibir respostas -->
            <div class="replies">
                <?php displayComments($pdo, $topic_id, $comment['id']); ?>
            </div>
        </div>
    <?php endforeach;
}

// Processar exclusão de post pelo admin
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_post']) &&
    isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'
) {
    try {
        // Deletar tags relacionadas
        $sql = "DELETE FROM redmasca_topicos_tags WHERE topic_id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['id' => $id]);
        // Agora deleta o post
        $sql = "DELETE FROM redmasca_topicos WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['id' => $id]);
        header("Location: read.php");
        exit();
    } catch (PDOException $e) {
        echo '<div class="error-message">Erro ao deletar post: ' . htmlspecialchars($e->getMessage()) . '</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($topic['title']) ?></title>
    <style>
        :root {
            --bg-color: #f0f2f5;
            --text-color: #1a1a1a;
            --navbar-bg: #fff;
            --post-bg: #fff;
            --post-shadow: rgba(0, 0, 0, 0.05);
            --border-color: #ddd;
            --tag-bg: #f5f5f5;
            --tag-color: #555;
            --dropdown-bg: #fff;
            --dropdown-shadow: rgba(0,0,0,0.2);
            --comment-bg: #f4f4f4;
            --comment-border: #ddd;
            --btn-primary: #ff9404;
            --btn-primary-hover: #e68503;
            --btn-secondary: #333;
            --btn-secondary-hover: #555;
        }

        [data-theme="dark"] {
            --bg-color: #1a1a1a;
            --text-color: #ffffff;
            --navbar-bg: #2d2d2d;
            --post-bg: #3a3a3a;
            --post-shadow: rgba(0, 0, 0, 0.3);
            --border-color: #555;
            --tag-bg: #555;
            --tag-color: #cccccc;
            --dropdown-bg: #3a3a3a;
            --dropdown-shadow: rgba(0,0,0,0.5);
            --comment-bg: #4a4a4a;
            --comment-border: #666;
            --btn-primary: #ff9404;
            --btn-primary-hover: #e68503;
            --btn-secondary: #666;
            --btn-secondary-hover: #777;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Arial, sans-serif;
        }

        body { 
            font-family: 'Segoe UI', Arial, sans-serif; 
            background-color: var(--bg-color); 
            color: var(--text-color);
            margin: 0; 
            padding: 0; 
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        h1, h2 { 
            color: var(--text-color); 
            font-weight: 600; 
        }

        .container { 
            width: 85%; 
            margin: 0 auto; 
            padding: 20px 0; 
        }

        .navbar {
            background: var(--navbar-bg);
            padding: 15px 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
            transition: background-color 0.3s ease;
        }

        .navbar .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar a {
            text-decoration: none;
            color: #ff9404;
            font-weight: 500;
            padding: 10px 20px;
            border-radius: 25px;
            transition: all 0.3s ease;
        }

        .navbar a:hover {
            background: #ff9404;
            color: #fff;
        }

        .post-container {
            background: var(--post-bg);
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px var(--post-shadow);
            transition: background-color 0.3s ease;
        }

        .post-container img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            margin: 15px 0;
        }

        .post-meta {
            color: var(--text-color);
            opacity: 0.7;
            margin: 10px 0;
            font-size: 0.9em;
        }

        .post-content {
            line-height: 1.6;
            margin: 20px 0;
        }

        .btn {
            background: var(--btn-primary);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin: 5px;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background: var(--btn-primary-hover);
        }

        .btn-secondary {
            background: var(--btn-secondary);
        }

        .btn-secondary:hover {
            background: var(--btn-secondary-hover);
        }

        .comment-section {
            background: var(--post-bg);
            padding: 25px;
            border-radius: 10px;
            margin-top: 20px;
            box-shadow: 0 4px 15px var(--post-shadow);
            transition: background-color 0.3s ease;
        }

        .comment-form {
            margin-bottom: 30px;
        }

        .comment-form textarea {
            width: 100%;
            padding: 15px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            background: var(--dropdown-bg);
            color: var(--text-color);
            font-family: inherit;
            resize: vertical;
            min-height: 100px;
            transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease;
        }

        .comment-form textarea:focus {
            outline: none;
            border-color: #ff9404;
        }

        .comment {
            margin: 15px 0;
            padding: 15px;
            border: 1px solid var(--comment-border);
            border-radius: 8px;
            background: var(--comment-bg);
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }

        .comment-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .comment-author {
            font-weight: bold;
            color: #ff9404;
        }

        .comment-date {
            font-size: 0.8em;
            color: var(--text-color);
            opacity: 0.7;
        }

        .comment-content {
            line-height: 1.5;
            margin-bottom: 10px;
        }

        .comment-form-inline {
            margin-top: 10px;
        }

        .comment-form-inline textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 5px;
            background: var(--dropdown-bg);
            color: var(--text-color);
            font-family: inherit;
            resize: vertical;
            min-height: 60px;
            margin-bottom: 10px;
            transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease;
        }

        .replies {
            margin-left: 30px;
            margin-top: 15px;
            padding-left: 15px;
            border-left: 2px solid var(--border-color);
        }

        .theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #ff9404;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 25px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s ease;
            z-index: 1001;
        }

        .theme-toggle:hover {
            background: #e68503;
        }

        .theme-toggle .icon {
            margin-right: 5px;
        }

        .back-button {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<button class="theme-toggle" onclick="toggleTheme()">
    <span class="icon">🌙</span>
    <span class="text">Modo Escuro</span>
</button>

<div class="navbar">
    <div class="container">
        <h1>Fórum RedMasca</h1>
        <div>
            <?php if (isset($_SESSION['user_id'])): ?>
                <span style="color: var(--text-color);">Bem-vindo, <?= htmlspecialchars($_SESSION['username']); ?>!</span>
                <a href="read.php">← Voltar ao Fórum</a>
                <a href="logout.php">Sair</a>
                <a href="editarDados.php">Editar Dados</a>
                <?php if ($_SESSION['user_role'] === 'admin'): ?>
                    <a href="admin.php">Área Admin</a>
                <?php endif; ?>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Register</a>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="container">   
    <div class="post-container">
        <h1><?= htmlspecialchars($topic['title']) ?></h1>
        
        <?php if ($topic['image_path']): ?>
            <img src="<?= htmlspecialchars($topic['image_path']) ?>" alt="Imagem do post">
        <?php endif; ?>
        
        <div class="post-meta">
            <strong>Categoria:</strong> <?= htmlspecialchars($topic['category_name']) ?>
        </div>
        
        <div class="post-content">
            <?= nl2br(htmlspecialchars($topic['content'])) ?>
        </div>

        <!-- Botões Editar e Deletar -->
        <?php if ($isCreator || (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin')): ?>
            <div style="margin-top: 20px;">
                <?php if ($isCreator): ?>
                    <a href="edit.php?id=<?= $topic['id'] ?>" class="btn">Editar Tópico</a>
                <?php endif; ?>
                <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'): ?>
                    <form method="post" action="" style="display:inline;">
                        <button type="submit" name="delete_post" class="btn btn-secondary" onclick="return confirm('Tem certeza que deseja deletar este tópico? Esta ação não pode ser desfeita.');">Deletar Tópico</button>
                    </form>
                <?php elseif ($isCreator): ?>
                    <a href="delete.php?id=<?= $topic['id'] ?>" class="btn btn-secondary" onclick="return confirm('Tem certeza que deseja deletar este tópico?');">Deletar Tópico</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="comment-section">
        <h2>Comentários</h2>
        
        <!-- Formulário para adicionar comentário -->
        <form method="post" action="" class="comment-form">
            <textarea name="comment" rows="3" required placeholder="Adicione um comentário..."></textarea>
            <button type="submit" class="btn">Comentar</button>
        </form>

        <!-- Exibir comentários -->
        <?php displayComments($pdo, $id); ?>
    </div>
</div>

<script>
// Função para alternar entre os temas
function toggleTheme() {
    const body = document.body;
    const themeToggle = document.querySelector('.theme-toggle');
    const icon = themeToggle.querySelector('.icon');
    const text = themeToggle.querySelector('.text');
    
    if (body.getAttribute('data-theme') === 'dark') {
        body.removeAttribute('data-theme');
        icon.textContent = '🌙';
        text.textContent = 'Modo Escuro';
        localStorage.setItem('theme', 'light');
    } else {
        body.setAttribute('data-theme', 'dark');
        icon.textContent = '☀️';
        text.textContent = 'Modo Claro';
        localStorage.setItem('theme', 'dark');
    }
}

// Carregar tema salvo ao carregar a página
document.addEventListener('DOMContentLoaded', function() {
    const savedTheme = localStorage.getItem('theme');
    const body = document.body;
    const themeToggle = document.querySelector('.theme-toggle');
    const icon = themeToggle.querySelector('.icon');
    const text = themeToggle.querySelector('.text');
    
    if (savedTheme === 'dark') {
        body.setAttribute('data-theme', 'dark');
        icon.textContent = '☀️';
        text.textContent = 'Modo Claro';
    }
});
</script>

</body>
</html>
