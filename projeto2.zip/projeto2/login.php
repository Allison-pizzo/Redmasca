<?php
// conexão com o banco de dados
require 'config.php';
// iniciar uma nova sessão ou retomar uma sessão existente
session_start();

$errorMessage = '';
$successMessage = '';

// Verificar se é uma solicitação de recuperação de senha
/*
               && isset($_POST['recover_password']))
verifica se o formulário foi submetido através de um botão chamado recover_password.

*/
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['recover_password'])) {
    $email = $_POST['email'];
    $username = $_POST['username'];
    
    // Verificar se o email e username existem
    /*
           $sql = "SELECT * FROM redmasca_usuario WHERE email = ? AND username = ?";
Esta linha define uma consulta SQL que seleciona todos os campos da tabela redmasca_usuario onde o email e o username correspondem aos valores fornecidos. Os sinais de interrogação (?) são marcadores de posição para parâmetros que serão vinculados posteriormente.

           $stmt = $pdo->prepare($sql);
Aqui, a consulta SQL é preparada usando o objeto $pdo, que é uma instância da classe PDO (PHP Data Objects). Isso ajuda a prevenir injeções de SQL, pois os parâmetros serão vinculados de forma segura

               $stmt->execute([$email, $username]);
 linha executa a consulta preparada, passando um array com os valores de $email e $username para substituir os marcadores de posição na consulta.

                   $user = $stmt->fetch();
Após a execução da consulta, esta linha busca o resultado. Se um usuário correspondente for encontrado, ele será armazenado na variável $user. Caso contrário, $user será false.

    */
    $sql = "SELECT * FROM redmasca_usuario WHERE email = ? AND username = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$email, $username]);
    $user = $stmt->fetch();
    
    //Esta condição verifica se um usuário foi encontrado. Se sim, o código dentro do bloco if será executado.
    if ($user) {
        
        // Gerar nova senha aleatória
        //Aqui, uma nova senha aleatória é gerada chamando a função generateRandomPassword().
        //A nova senha gerada é então criptografada usando a função password_hash(), que aplica um algoritmo de hash seguro. O resultado é armazenado em $hashed_password.
        $new_password = generateRandomPassword();
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        
        // Atualizar senha no banco
        //Uma nova consulta SQL é definida para atualizar a senha do usuário na tabela redmasca_usuario. A consulta é preparada e executada, substituindo os marcadores de posição pelos valores da nova senha hash, email e nome de usuário.
        $sql = "UPDATE redmasca_usuario SET password = ? WHERE email = ? AND username = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$hashed_password, $email, $username]);
        
        $successMessage = "Sua nova senha é: <strong>$new_password</strong><br>Faça login com esta senha e altere-a depois.";
    } else {
        $errorMessage = "Email ou nome de usuário não encontrados.";
    }
}

// Login normal
/*
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['recover_password'])) {
Esta linha verifica se a requisição HTTP é do tipo POST e se o parâmetro recover_password não está definido no array $_POST. Isso indica que o código deve ser executado apenas quando um formulário de login (e não um de recuperação de senha) é enviado.

               $sql = "SELECT * FROM redmasca_usuario WHERE email = ?";
 Esta linha define uma consulta SQL que seleciona todos os campos da tabela redmasca_usuario onde o email corresponde ao valor fornecido.

               $stmt = $pdo->prepare($sql);
   A consulta SQL é preparada usando o objeto $pdo, que é uma instância da classe PDO.


               $stmt->execute([$email]);
   A consulta preparada é executada, passando o valor do email como parâmetro.

               $user = $stmt->fetch();
   Após a execução da consulta, esta linha busca o resultado. Se um usuário correspondente for encontrado, ele será armazenado na variável $user. Caso contrário, $user será false.

               if ($user && password_verify($password, $user['password'])) {
 Esta condição verifica se um usuário foi encontrado e se a senha fornecida corresponde à senha armazenada no banco de dados. A função password_verify() é usada para comparar a senha fornecida com a senha hash armazenada.


                   $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['user_role'] = $user['role'];
Se as credenciais estiverem corretas, os dados do usuário (ID, nome de usuário e função) são armazenados na sessão. Isso permite que o usuário permaneça autenticado durante a navegação no site.

               header("Location: index.php");
                exit();
Após armazenar os dados do usuário na sessão, o código redireciona o usuário para a página index.php. A função exit() é chamada para garantir que o script pare de ser executado após o redirecionamento.

*/
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['recover_password'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM redmasca_usuario WHERE email = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['user_role'] = $user['role'];

        header("Location: index.php");
        exit();
    } else {
        $errorMessage = "Senha ou email inválidos.";
    }
}

// Função para gerar senha aleatória
/*
            function generateRandomPassword($length = 8) {
defenir o tamanho máximo da senha

        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
Define todos os caracteres possíveis para a senha
               for ($i = 0; $i < $length; $i++) {
Percorre de 0 até o comprimento desejado ($length)
Cada iteração adiciona um novo caractere aleatório à senha

                $password .= $chars[rand(0, strlen($chars) - 1)];
   rand(0, strlen($chars) - 1) gera um número aleatório entre 0 e o índice do último caractere
$chars[...] seleciona o caractere na posição aleatória
.= concatena o novo caractere à senha

            return $password;
Retorna a senha gerada como string


*/
function generateRandomPassword($length = 8) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $chars[rand(0, strlen($chars) - 1)];
    }
    return $password;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        :root {
            --bg-color: #f0f2f5;
            --form-bg: #fff;
            --text-color: #1a1a1a;
            --input-bg: #f7f7f7;
            --input-border: #ccc;
            --btn-primary: #ff9404;
            --btn-primary-hover: #e68503;
            --link: #ff9404;
            --error-bg: rgba(255,0,0,0.08);
            --error-color: #d32f2f;
            --success-bg: rgba(0,255,0,0.08);
            --success-color: #388e3c;
        }
        [data-theme="dark"] {
            --bg-color: #181a20;
            --form-bg: #23242b;
            --text-color: #fff;
            --input-bg: #23242b;
            --input-border: #444;
            --btn-primary: #ff9404;
            --btn-primary-hover: #e68503;
            --link: #ff9404;
            --error-bg: rgba(255,0,0,0.15);
            --error-color: #ff6b6b;
            --success-bg: rgba(0,255,0,0.15);
            --success-color: #90ee90;
        }
        html, body {
            height: 100%;
        }
        body {
            min-height: 100vh;
            background: var(--bg-color);
            color: var(--text-color);
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            transition: background 0.3s, color 0.3s;
        }
        .split-container {
            display: flex;
            min-height: 100vh;
        }
        .left-panel {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background: var(--bg-color);
            padding: 40px 20px;
        }
        .login-box {
            background: var(--form-bg);
            border-radius: 16px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.07);
            padding: 40px 32px;
            width: 100%;
            max-width: 370px;
            display: flex;
            flex-direction: column;
            align-items: stretch;
        }
        .login-box h2 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--text-color);
        }
        .login-box p.subtitle {
            color: var(--text-color);
            opacity: 0.7;
            margin-bottom: 32px;
            font-size: 1rem;
        }
        .login-box label {
            font-weight: 500;
            margin-bottom: 6px;
            color: var(--text-color);
        }
        .login-box input[type="email"],
        .login-box input[type="password"] {
            width: 100%;
            padding: 14px 12px;
            margin-bottom: 18px;
            border: 1px solid var(--input-border);
            border-radius: 6px;
            background: var(--input-bg);
            color: var(--text-color);
            font-size: 1rem;
            transition: border 0.2s, background 0.2s;
            box-sizing: border-box;
            font-family: inherit;
            outline: none;
        }
        .login-box input[type="email"]::placeholder,
        .login-box input[type="password"]::placeholder {
            color: var(--text-color);
            opacity: 0.6;
        }
        .login-box input[type="email"]:focus,
        .login-box input[type="password"]:focus {
            border-color: var(--btn-primary);
            background: var(--input-bg);
        }
        .login-box .row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 18px;
        }
        .login-box .remember {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 0.97em;
        }
        .login-box .forgot {
            color: var(--link);
            text-decoration: none;
            font-size: 0.97em;
            transition: text-decoration 0.2s;
        }
        .login-box .forgot:hover {
            text-decoration: underline;
        }
        .login-box button[type="submit"] {
            background: var(--btn-primary);
            color: #fff;
            border: none;
            border-radius: 6px;
            padding: 13px 0;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            margin-top: 10px;
            transition: background 0.2s;
        }
        .login-box button[type="submit"]:hover {
            background: var(--btn-primary-hover);
        }
        .login-box .register-link {
            margin-top: 24px;
            text-align: center;
            font-size: 1em;
        }
        .login-box .register-link a {
            color: var(--link);
            text-decoration: none;
            font-weight: 500;
        }
        .login-box .register-link a:hover {
            text-decoration: underline;
        }
        .error-message {
            background: var(--error-bg);
            color: var(--error-color);
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 18px;
            text-align: center;
        }
        .success-message {
            background: var(--success-bg);
            color: var(--success-color);
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 18px;
            text-align: center;
        }
        .theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #ff9404;
            color: white;
            border: none;
            padding: 8px 14px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 13px;
            transition: background-color 0.3s ease;
            z-index: 1001;
            display: inline-flex;
            align-items: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            min-width: unset;
            width: auto;
        }
        .theme-toggle .icon {
            margin-right: 5px;
        }
        .right-panel {
            flex: 1;
            min-height: 100vh;
            height: 100vh;
            display: flex;
            align-items: stretch;
            justify-content: stretch;
            background: linear-gradient(135deg, #a18cd1 0%, #fbc2eb 100%);
            padding: 0;
            border-top-right-radius: 0;
            border-bottom-right-radius: 0;
            overflow: hidden;
        }
        .right-panel img, .right-panel svg {
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center;
            border-radius: 0;
            box-shadow: none;
            display: block;
        }
        @media (max-width: 900px) {
            .split-container { flex-direction: column; }
            .right-panel { min-height: 300px; height: 300px; }
        }
        @media (max-width: 700px) {
            .split-container { flex-direction: column; }
            .right-panel { display: none; }
            .left-panel { flex: none; min-height: 100vh; }
        }
    </style>
</head>
<body>
<button class="theme-toggle" onclick="toggleTheme()">
    <span class="icon">🌙</span>
    <span class="text">Modo Escuro</span>
</button>
<div class="split-container">
    <div class="left-panel">
        <form method="POST" action="login.php" class="login-box" id="loginForm">
            
            
            <?php if (!empty($errorMessage)): ?>
                <div class="error-message"><?= htmlspecialchars($errorMessage) ?></div>
            <?php endif; ?>
            <?php if (!empty($successMessage)): ?>
                <div class="success-message"><?= $successMessage ?></div>
            <?php endif; ?>
            <label for="email">Email</label>
            <input type="email" name="email" placeholder="Digite seu email" required>
            <label for="password">Senha</label>
            <input type="password" name="password" placeholder="Digite sua senha" required>
            <div class="row">
                <span class="remember">
                    <input type="checkbox" id="remember" name="remember">
                    <label for="remember" style="margin-bottom:0;">Lembrar-me</label>
                </span>
                <a href="#" class="forgot" onclick="showRecoveryForm()">Esqueceu a senha?</a>
            </div>
            <button type="submit">Login</button>
            <div class="register-link">
                Não tem uma conta? <a href="register.php">Cadastre-se</a>
            </div>
        </form>
        <!-- Formulário de Recuperação (inicialmente oculto) -->
        <form method="POST" action="login.php" id="recoveryForm" class="login-box" style="display:none;">
            <h2>Recuperar Senha</h2>
            <p class="subtitle">Digite seu email e nome de usuário para gerar uma nova senha.</p>
            <label for="recovery_email">Email</label>
            <input type="email" name="email" placeholder="Digite seu email cadastrado" required>
            <label for="recovery_username">Nome de Usuário</label>
            <input type="text" name="username" placeholder="Digite seu nome de usuário" required>
            <button type="submit" name="recover_password">Gerar Nova Senha</button>
            <div class="register-link">
                <a href="#" onclick="showLoginForm()">Voltar ao Login</a>
            </div>
        </form>
    </div>
    <div class="right-panel">
        <img src="telalogin.jpeg" alt="Login Illustration">
    </div>
</div>
<script>
// Função para alternar entre os temas
function toggleTheme() {
    const body = document.body;
    const themeToggle = document.querySelector('.theme-toggle');
    const icon = themeToggle.querySelector('.icon');
    const text = themeToggle.querySelector('.text');
    if (body.getAttribute('data-theme') === 'dark') {
        body.removeAttribute('data-theme');
        icon.textContent = '🌙';
        text.textContent = 'Modo Escuro';
        localStorage.setItem('theme', 'light');
    } else {
        body.setAttribute('data-theme', 'dark');
        icon.textContent = '☀️';
        text.textContent = 'Modo Claro';
        localStorage.setItem('theme', 'dark');
    }
}
// Carregar tema salvo ao carregar a página
document.addEventListener('DOMContentLoaded', function() {
    const savedTheme = localStorage.getItem('theme');
    const body = document.body;
    const themeToggle = document.querySelector('.theme-toggle');
    const icon = themeToggle.querySelector('.icon');
    const text = themeToggle.querySelector('.text');
    if (savedTheme === 'dark') {
        body.setAttribute('data-theme', 'dark');
        icon.textContent = '☀️';
        text.textContent = 'Modo Claro';
    }
});
// Alternar entre login e recuperação
function showRecoveryForm() {
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('recoveryForm').style.display = 'flex';
}
function showLoginForm() {
    document.getElementById('loginForm').style.display = 'flex';
    document.getElementById('recoveryForm').style.display = 'none';
}
</script>
</body>
</html>
