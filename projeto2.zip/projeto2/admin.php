<?php
include 'config.php';
session_start();

// Verifica se o usuário é admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit();
}
$mensagem = "";
$mensagem_sucesso = "";

try {
    /*Esta linha inicia um bloco try, que é usado para capturar exceções (erros) que podem ocorrer durante a execução do código dentro dele. Se uma exceção for lançada, o controle será passado para o bloco catch correspondente (que não está incluído no trecho que você forneceu).

     Posts pendentes (ativos e não aprovados)

                                 stmt = $pdo->query("
    Aqui, uma consulta SQL é executada usando o objeto $pdo, que é uma instância da classe PDO (PHP Data Objects) para interagir com um banco de dados.

                                SELECT t.*, c.name AS category_name
                                    FROM redmasca_topicos t
A consulta seleciona todos os campos da tabela redmasca_topicos (referenciada como t) e o nome da categoria da tabela redmasca_categorias (referenciada como c).

                            JOIN redmasca_categorias c ON t.category_id = c.id
A cláusula JOIN é usada para combinar as duas tabelas com base na condição de que o category_id da tabela redmasca_topicos deve corresponder ao id da tabela redmasca_categorias.

                            WHERE t.approved = 0 AND t.active = 1
A cláusula WHERE filtra os resultados para incluir apenas os tópicos que não foram aprovados (t.approved = 0) e que estão ativos (t.active = 1).*/
    $stmt = $pdo->query("
        SELECT t.*, c.name AS category_name
        FROM redmasca_topicos t
        JOIN redmasca_categorias c ON t.category_id = c.id
        WHERE t.approved = 0 AND t.active = 1
    ");
    $pending_posts = $stmt->fetchAll();
// Esta linha armazena todos os resultados da consulta SQL na variável $pending_posts. O método fetchAll() retorna um array contendo todas as linhas resultantes da consulta


    // Posts desativados (histórico)
    /*
                                 SELECT t.*, c.name AS category_name
                                  FROM redmasca_topicos t
    consulta seleciona todos os campos da tabela redmasca_topicos (referenciada como t) e o campo name da tabela redmasca_categorias (referenciada como c), que é renomeado como category_name.

                            JOIN redmasca_categorias c ON t.category_id = c.id
A cláusula JOIN é usada para combinar as tabelas redmasca_topicos e redmasca_categorias com base na condição de que t.category_id deve ser igual a c.id.

                                WHERE t.active = 0
A cláusula WHERE filtra os resultados para incluir apenas os tópicos que estão inativos (t.active = 0).*/
    $stmt = $pdo->query("
        SELECT t.*, c.name AS category_name
        FROM redmasca_topicos t
        JOIN redmasca_categorias c ON t.category_id = c.id
        WHERE t.active = 0
    ");
    $deactivated_posts = $stmt->fetchAll();
    /*Após a execução da consulta, o método fetchAll() é chamado no objeto $stmt, que retorna todos os resultados da consulta em um array. Este array é armazenado na variável $deactivated_posts.
Portanto, $deactivated_posts conterá todos os tópicos inativos, juntamente com o nome da categoria correspondente.*/
} catch (PDOException $e) {
    $mensagem = "Erro ao carregar os posts: " . $e->getMessage();
    /*Este bloco catch é usado para capturar exceções do tipo PDOException, que podem ocorrer durante a execução da consulta SQL.
Se uma exceção for lançada, a variável $mensagem é definida com uma string que inclui a mensagem de erro gerada pela exceção, permitindo que você saiba o que deu errado ao tentar carregar os posts.*/

}

// Aprova post
/*
                            if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve'])) {
Esta linha verifica se o método da requisição HTTP é POST e se o campo approve está definido no array $_POST.
Isso é usado para garantir que o código dentro do bloco if só será executado quando um formulário for enviado com o método POST e que a intenção é aprovar um post.

O bloco try é iniciado para capturar possíveis exceções que podem ocorrer durante a execução do código dentro dele.

                            sql = "UPDATE redmasca_topicos SET approved = 1 WHERE id = :id";
Aqui, uma string SQL é definida para atualizar a tabela redmasca_topicos, definindo o campo approved como 1 (aprovado) para o post que corresponde ao id fornecido.

                                    stmt = $pdo->prepare($sql);
O método prepare() do objeto $pdo é chamado para preparar a consulta SQL, o que ajuda a prevenir injeções de SQL.

                                stmt->execute(['id' => $_POST['post_id']]);
O método execute() é chamado no objeto $stmt para executar a consulta preparada. O valor do id é passado como um parâmetro, que é obtido do array $_POST usando a chave post_id.

Isso efetivamente atualiza o status de aprovação do post correspondente ao id fornecido.
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve'])) {
    try {
        $sql = "UPDATE redmasca_topicos SET approved = 1 WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['id' => $_POST['post_id']]);
        $mensagem_sucesso = "Post aprovado com sucesso.";
        header("Location: admin.php");
        exit();
    } catch (PDOException $e) {
        $mensagem = "Erro ao aprovar post: " . $e->getMessage();
        /*Se ocorrer uma exceção do tipo PDOException durante a execução da consulta, o bloco catch captura a exceção.
A variável $mensagem é definida com uma string que inclui a mensagem de erro gerada pela exceção, permitindo que você saiba o que deu errado ao tentar aprovar o post.
*/
    }
}

// Desativa post
/*
                        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deactivate'])) {
Verificação do Método de Requisição: Esta linha verifica se o método da requisição HTTP é POST e se o campo deactivate foi enviado no formulário. Isso é comum em formulários que realizam ações, como desativar um post.

                        $sql = "UPDATE redmasca_topicos SET active = 0 WHERE id = :id";
Definição da Consulta SQL: Aqui, uma string SQL é definida para atualizar a tabela redmasca_topicos, definindo a coluna active como 0 (desativando o post) onde o id do post corresponde ao valor que será passado.

                        $stmt = $pdo->prepare($sql);
Preparação da Consulta: O método prepare é chamado no objeto de conexão $pdo para preparar a consulta SQL. Isso ajuda a prevenir injeções de SQL, pois os parâmetros serão vinculados de forma segura.

                        $stmt->execute(['id' => $_POST['post_id']]);
 Execução da Consulta: O método execute é chamado para executar a consulta preparada. O valor do id é passado a partir do array associativo, onde $_POST['post_id'] contém o ID do post que deve ser desativado.
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deactivate'])) {
    try {
        $sql = "UPDATE redmasca_topicos SET active = 0 WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['id' => $_POST['post_id']]);
        $mensagem_sucesso = "Post desativado com sucesso.";
        header("Location: admin.php");
        exit();
    } catch (PDOException $e) {
        $mensagem = "Erro ao desativar post: " . $e->getMessage();
    }
}

// Reativa post

/*
                        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reactivate'])) {
Verificação do Método de Requisição: Esta linha verifica se o método da requisição HTTP é POST e se o campo reactivate foi enviado no formulário. Isso é comum em formulários que realizam ações, como reativar um post.

                        $sql = "UPDATE redmasca_topicos SET active = 1 WHERE id = :id";
Definição da Consulta SQL: Aqui, uma string SQL é definida para atualizar a tabela redmasca_topicos, definindo a coluna active como 1 (reativando o post) onde o id do post corresponde ao valor que será passado.

                        $stmt = $pdo->prepare($sql);
Preparação da Consulta: O método prepare é chamado no objeto de conexão $pdo para preparar a consulta SQL. Isso ajuda a prevenir injeções de SQL, pois os parâmetros serão vinculados de forma segura.

                        $stmt->execute(['id' => $_POST['post_id']]);
Execução da Consulta: O método execute é chamado para executar a consulta preparada. O valor do id é passado a partir do array associativo, onde $_POST['post_id'] contém o ID do post que deve ser reativado.


*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reactivate'])) {
    try {
        $sql = "UPDATE redmasca_topicos SET active = 1 WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['id' => $_POST['post_id']]);
        $mensagem_sucesso = "Post reativado com sucesso.";
        header("Location: admin.php");
        exit();
    } catch (PDOException $e) {
        $mensagem = "Erro ao reativar post: " . $e->getMessage();
        /*Captura de Exceções: Se ocorrer um erro durante a execução do bloco try, o controle é passado para este bloco catch, que captura a exceção lançada.
        Mensagem de Erro: Se uma exceção for capturada, uma mensagem de erro é definida, incluindo a mensagem específica do erro que ocorreu, obtida através de $e->getMessage(). */
    }
}

// Deleta post
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'])) {
    try {
        // Deletar tags relacionadas
        $sql = "DELETE FROM redmasca_topicos_tags WHERE topic_id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['id' => $_POST['post_id']]);
        // Agora deleta o post
        $sql = "DELETE FROM redmasca_topicos WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['id' => $_POST['post_id']]);
        $mensagem_sucesso = "Post deletado com sucesso.";
        header("Location: admin.php");
        exit();
    } catch (PDOException $e) {
        $mensagem = "Erro ao deletar post: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Administração de Posts</title>
    <style>
        :root {
            --bg-color: #f0f2f5;
            --container-bg: #fff;
            --text-color: #333;
            --card-bg: #fafafa;
            --card-border: #ddd;
            --text-secondary: #555;
            --btn-primary: #ff9404;
            --btn-primary-hover: #e68503;
            --btn-secondary: #999;
            --btn-secondary-hover: #777;
        }

        [data-theme="dark"] {
            --bg-color: #1a1a1a;
            --container-bg: #2d2d2d;
            --text-color: #ffffff;
            --card-bg: #3a3a3a;
            --card-border: #555;
            --text-secondary: #cccccc;
            --btn-primary: #ff9404;
            --btn-primary-hover: #e68503;
            --btn-secondary: #666;
            --btn-secondary-hover: #555;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: var(--bg-color);
            color: var(--text-color);
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        
        .container {
            background: var(--container-bg);
            max-width: 800px;
            margin: 50px auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
            transition: background-color 0.3s ease;
        }
        
        h1, h2 {
            text-align: center;
            color: var(--text-color);
        }
        
        .post-card {
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }
        
        .post-card h3 {
            margin: 0 0 10px;
            color: var(--text-color);
        }
        
        .post-card p {
            margin: 5px 0;
            color: var(--text-secondary);
        }
        
        form.inline-form {
            display: inline-block;
            margin-right: 10px;
        }
        
        .btn {
            background: var(--btn-primary);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        
        .btn:hover {
            background: var(--btn-primary-hover);
        }
        
        .btn-deactivate {
            background: var(--btn-secondary);
        }
        
        .btn-deactivate:hover {
            background: var(--btn-secondary-hover);
        }
        
        .mensagem, .mensagem-sucesso {
            text-align: center;
            margin-top: 20px;
        }
        
        .mensagem {
            color: red;
        }
        
        .mensagem-sucesso {
            color: green;
        }

        .theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--btn-primary);
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 25px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s ease;
            z-index: 1000;
        }

        .theme-toggle:hover {
            background: var(--btn-primary-hover);
        }

        .theme-toggle .icon {
            margin-right: 5px;
        }
    </style>
</head>
<body>

<button class="theme-toggle" onclick="toggleTheme()">
    <span class="icon">🌙</span>
    <span class="text">Modo Escuro</span>
</button>

<div class="container">
    <h1>Painel Administrativo</h1>

    <div style="text-align: center; margin-bottom: 20px;">
        <a href="read.php" class="btn" style="text-decoration: none; display: inline-block; margin: 0 10px;">
            ← Voltar ao Fórum
        </a>
    </div>

    <?php if ($mensagem): ?>
        <div class="mensagem"><?= $mensagem ?></div>
    <?php endif; ?>

    <?php if ($mensagem_sucesso): ?>
        <div class="mensagem-sucesso"><?= $mensagem_sucesso ?></div>
    <?php endif; ?>

    <h2>Posts Pendentes</h2>
    <?php if (count($pending_posts) > 0): ?>
        <?php foreach ($pending_posts as $post): ?>
            <div class="post-card">
                <h3><?= htmlspecialchars($post['title']) ?></h3>
                <p><?= nl2br(htmlspecialchars($post['content'])) ?></p>
                <p><strong>Categoria:</strong> <?= htmlspecialchars($post['category_name']) ?></p>
                <form method="post" class="inline-form">
                    <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                    <button type="submit" name="approve" class="btn">Aprovar</button>
                </form>
                <form method="post" class="inline-form">
                    <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                    <button type="submit" name="deactivate" class="btn btn-deactivate" onclick="return confirm('Deseja desativar este post?');">Desativar</button>
                </form>              
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p style="text-align: center;">Nenhum post pendente no momento.</p>
    <?php endif; ?>

    <h2>Histórico de Postagens</h2>
    <?php if (count($deactivated_posts) > 0): ?>
        <?php foreach ($deactivated_posts as $post): ?>
            <div class="post-card">
                <h3><?= htmlspecialchars($post['title']) ?> <span style="color: red;">(Desativado)</span></h3>
                <p><?= nl2br(htmlspecialchars($post['content'])) ?></p>
                <p><strong>Categoria:</strong> <?= htmlspecialchars($post['category_name']) ?></p>
                <p><strong>Status de aprovação:</strong> <?= $post['approved'] ? 'Aprovado' : 'Não aprovado' ?></p>
                <form method="post" class="inline-form">
                    <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                    <button type="submit" name="reactivate" class="btn" onclick="return confirm('Deseja reativar este post?');">Reativar</button>
                </form>
                <form method="post" class="inline-form">
                    <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                    <button type="submit" name="delete" class="btn btn-deactivate" onclick="return confirm('Tem certeza que deseja deletar este post? Esta ação não pode ser desfeita.');">Deletar</button>
                </form>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p style="text-align: center;">Nenhum post desativado no histórico.</p>
    <?php endif; ?>
</div>

<script>
// Função para alternar entre os temas
function toggleTheme() {
    const body = document.body;
    const themeToggle = document.querySelector('.theme-toggle');
    const icon = themeToggle.querySelector('.icon');
    const text = themeToggle.querySelector('.text');
    
    if (body.getAttribute('data-theme') === 'dark') {
        body.removeAttribute('data-theme');
        icon.textContent = '🌙';
        text.textContent = 'Modo Escuro';
        localStorage.setItem('theme', 'light');
    } else {
        body.setAttribute('data-theme', 'dark');
        icon.textContent = '☀️';
        text.textContent = 'Modo Claro';
        localStorage.setItem('theme', 'dark');
    }
}

// Carregar tema salvo ao carregar a página
document.addEventListener('DOMContentLoaded', function() {
    const savedTheme = localStorage.getItem('theme');
    const body = document.body;
    const themeToggle = document.querySelector('.theme-toggle');
    const icon = themeToggle.querySelector('.icon');
    const text = themeToggle.querySelector('.text');
    
    if (savedTheme === 'dark') {
        body.setAttribute('data-theme', 'dark');
        icon.textContent = '☀️';
        text.textContent = 'Modo Claro';
    }
});
</script>

</body>
</html>
