<?php
// conexão com o banco de dados
include 'config.php';
// iniciar uma nova sessão ou retomar uma sessão existente
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
//Atribuição do ID do Usuário: Se o usuário estiver logado (ou seja, se user_id estiver definido), o código atribui o valor de $_SESSION['user_id'] à variável $user_id. Isso permite que você use $user_id em outras partes do código para referenciar o usuário autenticado.
$user_id = $_SESSION['user_id'];

// Ativar erros do PDO
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Busca os dados do usuário
/*
            try { ... } catch { ... }
É uma estrutura de tratamento de exceções.
Se algum erro ocorrer dentro do bloco try, o bloco catch será executado.
PDOException $e captura erros específicos de PDO ($e contém detalhes do erro).

                $sql = "SELECT * FROM redmasca_usuario WHERE id = :id";
$sql armazena a query SQL.
SELECT * FROM redmasca_usuario: busca todos os campos da tabela redmasca_usuario.
WHERE id = :id: usa um named parameter (:id), evitando SQL Injection (mais seguro que concatenar valores diretamente).

                $stmt = $pdo->prepare($sql);
$pdo->prepare() prepara a query SQL para execução.
$stmt (statement) é um objeto que representa a query preparada.

                $stmt->execute(['id' => $user_id]);
execute(['id' => $user_id]) roda a query substituindo :id pelo valor de $user_id.
$user_id vem da variável $_SESSION['user_id'] anterior.

                $user = $stmt->fetch(PDO::FETCH_ASSOC);
fetch(PDO::FETCH_ASSOC) busca o resultado como um array associativo (ex.: ['id' => 1, 'nome' => 'João']).
Se não houver resultados, retorna false.

                if (!$user) {
                    die("Erro: Usuário não encontrado.");               
Verifica se $user existe (se a query retornou algo).
Se não existir (!$user), exibe a mensagem "Erro: Usuário não encontrado." e encerra o script (die).
*/
try {
    $sql = "SELECT * FROM redmasca_usuario WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        die("Erro: Usuário não encontrado.");
    }
} catch (PDOException $e) {
    die("Erro ao buscar usuário: " . $e->getMessage());
}

// Busca cursos
/*
                $stmt = $pdo->query("SELECT * FROM redmasca_categorias");
pdo->query() executa uma consulta SQL diretamente.
SELECT * FROM redmasca_categorias busca todos os registros da tabela redmasca_categorias

                $courses = $stmt->fetchAll();
fetchAll() retorna todos os resultados da consulta como um array.

            } catch (PDOException $e) {
    die("Erro ao buscar cursos: " . $e->getMessage());
Captura a exceção (PDOException).
Exibe a mensagem de erro específica ($e->getMessage()).
Encerra o script (die).
*/
try {
    $stmt = $pdo->query("SELECT * FROM redmasca_categorias");
    $courses = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Erro ao buscar cursos: " . $e->getMessage());
}

// Mensagens de feedback
$mensagem = "";
$mensagem_sucesso = "";

// Processa o formulário
/*
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
verifica se o método de requisição é POST

            $username = trim($_POST['username']);
            $email = trim($_POST['email']);
            $curso_id = $_POST['curso_id'];
            $password = $_POST['password'];
            $confirm_password = $_POST['confirm_password'];
$_POST: Esta variável superglobal contém os dados enviados pelo formulário via método POST.
trim(): A função trim() remove espaços em branco do início e do fim de uma string. Isso é útil para evitar problemas com entradas que podem ter espaços desnecessários.
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $curso_id = $_POST['curso_id'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Verifica se username ou email já existem
/*
        $sql = "SELECT * FROM redmasca_usuario WHERE (username = :username OR email = :email) AND id != :id";
   Esta linha define uma consulta SQL que seleciona todos os registros da tabela redmasca_usuario.


           $stmt = $pdo->prepare($sql);
   Aqui, a consulta SQL é preparada usando o objeto $pdo, que é uma instância da classe PDO (PHP Data Objects). Isso ajuda a prevenir injeções de SQL.

               $stmt->execute([
            'username' => $username,
            'email' => $email,
            'id' => $user_id
A consulta preparada é executada com os parâmetros fornecidos. Os valores de $username, $email e $user_id são passados como um array associativo, onde as chaves correspondem aos marcadores de posição na consulta SQL.

               $existingUser  = $stmt->fetch(PDO::FETCH_ASSOC);
Esta linha busca o primeiro resultado da consulta executada. O método fetch(PDO::FETCH_ASSOC) retorna o resultado como um array associativo. Se não houver resultados, $existingUser  será false.

               if ($existingUser ) {
                $mensagem = "Nome de usuário ou e-mail já em uso por outro usuário.";
            } else {
Aqui, o código verifica se um usuário existente foi encontrado. Se $existingUser  não for false, significa que já existe um usuário com o mesmo nome de usuário ou e-mail, e uma mensagem de erro é definida.
*/

    $sql = "SELECT * FROM redmasca_usuario WHERE (username = :username OR email = :email) AND id != :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'username' => $username,
        'email' => $email,
        'id' => $user_id
    ]);
    $existingUser = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existingUser) {
        $mensagem = "Nome de usuário ou e-mail já em uso por outro usuário.";
    } else {
        // Atualiza nome de usuário, email e curso
/*
   $sql = "UPDATE redmasca_usuario SET username = :username, email = :email, curso_id = :curso_id WHERE id = :id";
   $stmt = $pdo->prepare($sql);
   $stmt->execute([
       'username' => $username,
       'email' => $email,
       'curso_id' => $curso_id,
       'id' => $user_id
   ]);
   Se não houver conflitos de nome de usuário ou e-mail, o código prossegue para atualizar o registro do usuário. Uma nova consulta SQL é definida para atualizar o username, email e curso_id do usuário com o id correspondente.
A consulta é preparada e executada da mesma forma que a consulta anterior, utilizando os novos valores.

*/

        $sql = "UPDATE redmasca_usuario SET username = :username, email = :email, curso_id = :curso_id WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'username' => $username,
            'email' => $email,
            'curso_id' => $curso_id,
            'id' => $user_id
        ]);

        // Atualiza senha se fornecida e confirmada
/*
               if (!empty($password)) {
Esta linha verifica se a variável $password não está vazia. Isso significa que o usuário forneceu uma nova senha.

                if ($password === $confirm_password) {
Aqui, o código verifica se a nova senha fornecida ($password) é igual à senha de confirmação ($confirm_password). Isso é importante para garantir que o usuário digitou a senha corretamente.

                   $hashed_password = password_hash($password, PASSWORD_DEFAULT);
Se as senhas coincidirem, a nova senha é criptografada usando a função password_hash(), que aplica um algoritmo de hashing seguro. O resultado é armazenado na variável $hashed_password.

                   $sql = "UPDATE redmasca_usuario SET password = :password WHERE id = :id";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([
                        'password' => $hashed_password,
                        'id' => $user_id
Uma consulta SQL é definida para atualizar a coluna password na tabela redmasca_usuario com a nova senha hash. A consulta é preparada e executada, passando o novo valor da senha e o id do usuário.

   

*/
        if (!empty($password)) {
            if ($password === $confirm_password) {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $sql = "UPDATE redmasca_usuario SET password = :password WHERE id = :id";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    'password' => $hashed_password,
                    'id' => $user_id
                ]);
                $mensagem_sucesso .= "Senha atualizada com sucesso.<br>";
            } else {
                $mensagem .= "As senhas não coincidem.<br>";
            }
        }

        if (empty($mensagem)) {
            $mensagem_sucesso .= "Dados atualizados com sucesso.";
        }
    }

    // Atualiza os dados exibidos no formulário
    /*
Finalmente, os dados do usuário (nome de usuário, e-mail e ID do curso) são atualizados no array $user
    */
    $user['username'] = $username;
    $user['email'] = $email;
    $user['curso_id'] = $curso_id;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Dados</title>
    <style>
        :root {
            --bg-color: #f0f2f5;
            --text-color: #1a1a1a;
            --navbar-bg: #fff;
            --form-bg: #fff;
            --form-shadow: rgba(0,0,0,0.05);
            --border-color: #ccc;
            --input-bg: #fff;
            --label-color: #555;
            --btn-primary: #ff9404;
            --btn-primary-hover: #e68503;
            --error-color: red;
            --success-color: green;
        }

        [data-theme="dark"] {
            --bg-color: #1a1a1a;
            --text-color: #ffffff;
            --navbar-bg: #2d2d2d;
            --form-bg: #3a3a3a;
            --form-shadow: rgba(0,0,0,0.3);
            --border-color: #555;
            --input-bg: #4a4a4a;
            --label-color: #cccccc;
            --btn-primary: #ff9404;
            --btn-primary-hover: #e68503;
            --error-color: #ff6b6b;
            --success-color: #90ee90;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Arial, sans-serif;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: var(--bg-color);
            color: var(--text-color);
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .navbar {
            background: var(--navbar-bg);
            padding: 15px 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
            transition: background-color 0.3s ease;
        }

        .navbar .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 85%;
            margin: 0 auto;
        }

        .navbar a {
            text-decoration: none;
            color: #ff9404;
            font-weight: 500;
            padding: 10px 35px;
            border-radius: 25px;
            transition: all 0.3s ease;
        }

        .navbar a:hover {
            background: #ff9404;
            color: #fff;
        }

        .form-container {
            background: var(--form-bg);
            max-width: 500px;
            margin: 50px auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px var(--form-shadow);
            transition: background-color 0.3s ease;
        }

        h1 {
            text-align: center;
            color: var(--text-color);
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-top: 15px;
            color: var(--label-color);
            font-weight: 500;
        }

        input, select {
            width: 100%;
            padding: 12px;
            margin-top: 5px;
            border: 1px solid var(--border-color);
            border-radius: 5px;
            background: var(--input-bg);
            color: var(--text-color);
            font-size: 14px;
            transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease;
        }

        input:focus, select:focus {
            outline: none;
            border-color: #ff9404;
            box-shadow: 0 0 5px rgba(255, 148, 4, 0.3);
        }

        input::placeholder {
            color: var(--label-color);
            opacity: 0.7;
        }

        button {
            background: var(--btn-primary);
            color: white;
            border: none;
            padding: 12px;
            border-radius: 5px;
            margin-top: 20px;
            width: 100%;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background: var(--btn-primary-hover);
        }

        .mensagem {
            margin-top: 15px;
            color: var(--error-color);
            padding: 10px;
            border-radius: 5px;
            background-color: rgba(255, 0, 0, 0.1);
            border: 1px solid rgba(255, 0, 0, 0.2);
        }

        .mensagem-sucesso {
            margin-top: 15px;
            color: var(--success-color);
            padding: 10px;
            border-radius: 5px;
            background-color: rgba(0, 255, 0, 0.1);
            border: 1px solid rgba(0, 255, 0, 0.2);
        }

        .theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #ff9404;
            color: white;
            border: none;
            padding: 8px 14px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 13px;
            transition: background-color 0.3s ease;
            z-index: 1001;
            display: inline-flex;
            align-items: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            min-width: unset;
            width: auto;
        }

        .theme-toggle .icon {
            margin-right: 5px;
        }

        .back-button {
            margin-bottom: 20px;
        }

        .back-button .btn {
            background: #666;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            display: inline-block;
            transition: background-color 0.3s ease;
        }

        .back-button .btn:hover {
            background: #777;
        }
    </style>
</head>
<body>

<button class="theme-toggle" onclick="toggleTheme()">
    <span class="icon">🌙</span>
    <span class="text">Modo Escuro</span>
</button>

<div class="navbar">
    <div class="container">
        <h1>Fórum RedMasca</h1>
        <div>
            <span style="color: var(--text-color);">Bem-vindo, <?= htmlspecialchars($_SESSION['username']); ?>!</span>
            <a href="read.php">← Voltar ao Fórum</a>
            <a href="logout.php">Sair</a>
            <?php if ($_SESSION['user_role'] === 'admin'): ?>
                <a href="admin.php">Área Admin</a>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="form-container">
    

    <h1>Editar Dados</h1>
    <?php if ($mensagem): ?>
        <div class="mensagem"><?= $mensagem ?></div>
    <?php endif; ?>

    <?php if ($mensagem_sucesso): ?>
        <div class="mensagem-sucesso"><?= $mensagem_sucesso ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <label for="username">Usuário:</label>
        <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>

        <label for="email">Email:</label>
        <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>

        <label for="curso_id">Curso:</label>
        <select name="curso_id" required>
            <option value="">Selecione um curso</option>
            <?php foreach ($courses as $course): ?>
                <option value="<?= $course['id'] ?>" <?= $course['id'] == $user['curso_id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($course['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="password">Nova Senha:</label>
        <input type="password" name="password" placeholder="Nova senha (opcional)">

        <label for="confirm_password">Confirmar Nova Senha:</label>
        <input type="password" name="confirm_password" placeholder="Confirme a nova senha">

        <button type="submit">Salvar Alterações</button>
    </form>
</div>

<script>
// Função para alternar entre os temas
function toggleTheme() {
    const body = document.body;
    const themeToggle = document.querySelector('.theme-toggle');
    const icon = themeToggle.querySelector('.icon');
    const text = themeToggle.querySelector('.text');
    
    if (body.getAttribute('data-theme') === 'dark') {
        body.removeAttribute('data-theme');
        icon.textContent = '🌙';
        text.textContent = 'Modo Escuro';
        localStorage.setItem('theme', 'light');
    } else {
        body.setAttribute('data-theme', 'dark');
        icon.textContent = '☀️';
        text.textContent = 'Modo Claro';
        localStorage.setItem('theme', 'dark');
    }
}

// Carregar tema salvo ao carregar a página
document.addEventListener('DOMContentLoaded', function() {
    const savedTheme = localStorage.getItem('theme');
    const body = document.body;
    const themeToggle = document.querySelector('.theme-toggle');
    const icon = themeToggle.querySelector('.icon');
    const text = themeToggle.querySelector('.text');
    
    if (savedTheme === 'dark') {
        body.setAttribute('data-theme', 'dark');
        icon.textContent = '☀️';
        text.textContent = 'Modo Claro';
    }
});
</script>

</body>
</html>
